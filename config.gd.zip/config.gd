extends Node

# Глобальные настройки игры (autoload "GameConfig").
# Меняются из меню, читаются при генерации лабиринта.

var cols: int = 16            # ширина лабиринта (клеток)
var rows: int = 10            # высота лабиринта (клеток)
var station_count: int = 8    # число подзарядных станций (базовое)
var player_speed: float = 320.0
var max_energy: float = 1.7   # запас света (макс. заряд)
var drain_per_sec: float = 0.055  # скорость разрядки свечения
var darkness: float = 0.05    # уровень общей темноты (меньше = темнее)
var door_pairs: int = 1       # пар дверей между соседними этажами

var lives: int = 3            # число жизней на уровень

var events_enabled: bool = true       # случайные события
var progressive_enabled: bool = true  # накопительные пассивки

var door_regen_enabled: bool = false  # шанс перегенерации лабиринта при переходе
var door_regen_chance: float = 0.3    # вероятность (0..1)

var darkness_chaser: bool = true      # тьма-преследователь (с уровня 4)

var touch_controls: bool = false      # принудительно показывать сенсорное управление
									  # (на телефоне показывается автоматически)

var level: int = 1            # текущий уровень (1..10), растёт при прохождении
var saved_level: int = 1      # автосохранение: с какого уровня продолжать

# Выбранные пассивные навыки (включаются в меню)
var passives := {
	"save": false,      # разрядка −30%
	"capacity": false,  # макс. заряд +30%
	"charge": false,    # зарядка на станциях +50%
	"range": false,     # радиус свечения +25%
	"legs": false,      # скорость +15%
	"magic": false,     # навыки дешевле и быстрее перезаряжаются
}

const SAVE_PATH := "user://maze.cfg"

func _ready() -> void:
	load_game()

func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)

func save_game() -> void:
	var c := ConfigFile.new()
	c.set_value("run", "saved_level", saved_level)
	c.set_value("set", "cols", cols)
	c.set_value("set", "rows", rows)
	c.set_value("set", "station_count", station_count)
	c.set_value("set", "player_speed", player_speed)
	c.set_value("set", "max_energy", max_energy)
	c.set_value("set", "drain_per_sec", drain_per_sec)
	c.set_value("set", "darkness", darkness)
	c.set_value("set", "door_pairs", door_pairs)
	c.set_value("set", "lives", lives)
	c.set_value("set", "events_enabled", events_enabled)
	c.set_value("set", "progressive_enabled", progressive_enabled)
	c.set_value("set", "door_regen_enabled", door_regen_enabled)
	c.set_value("set", "door_regen_chance", door_regen_chance)
	c.set_value("set", "darkness_chaser", darkness_chaser)
	c.set_value("set", "touch_controls", touch_controls)
	c.set_value("set", "passives", passives)
	c.save(SAVE_PATH)

func load_game() -> void:
	var c := ConfigFile.new()
	if c.load(SAVE_PATH) != OK:
		return
	saved_level = c.get_value("run", "saved_level", saved_level)
	cols = c.get_value("set", "cols", cols)
	rows = c.get_value("set", "rows", rows)
	station_count = c.get_value("set", "station_count", station_count)
	player_speed = c.get_value("set", "player_speed", player_speed)
	max_energy = c.get_value("set", "max_energy", max_energy)
	drain_per_sec = c.get_value("set", "drain_per_sec", drain_per_sec)
	darkness = c.get_value("set", "darkness", darkness)
	door_pairs = c.get_value("set", "door_pairs", door_pairs)
	lives = c.get_value("set", "lives", lives)
	events_enabled = c.get_value("set", "events_enabled", events_enabled)
	progressive_enabled = c.get_value("set", "progressive_enabled", progressive_enabled)
	door_regen_enabled = c.get_value("set", "door_regen_enabled", door_regen_enabled)
	door_regen_chance = c.get_value("set", "door_regen_chance", door_regen_chance)
	darkness_chaser = c.get_value("set", "darkness_chaser", darkness_chaser)
	touch_controls = c.get_value("set", "touch_controls", touch_controls)
	passives = c.get_value("set", "passives", passives)
