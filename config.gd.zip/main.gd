extends Node2D

const TILE := 48.0        # размер одной клетки сетки в пикселях
const MAX_LEVEL := 10     # всего уровней
const MAX_FLOORS := 4     # потолок числа этажей
const MAX_DIM := 36       # потолок размера лабиринта по стороне
const MAX_STATIONS := 40  # потолок станций на этаж (защита от мерцания света)
const SHARDS_PER_FLOOR := 5  # осколков света на этаж

const FLOOR_COLOR := Color(0.10, 0.11, 0.15)  # цвет пола (виден только при свете)

# Цвета стен по уровням (для визуального разнообразия)
const WALL_THEMES := [
	Color(0.20, 0.23, 0.34),  # синий
	Color(0.30, 0.22, 0.30),  # фиолетовый
	Color(0.20, 0.30, 0.26),  # зелёный
	Color(0.32, 0.26, 0.20),  # охра
	Color(0.30, 0.20, 0.22),  # красный
]
var _wall_color: Color = WALL_THEMES[0]

var _level: int
var _floors: int
var _cols: int
var _rows: int
var _gw: int
var _gh: int
var _floor_gap: float
var _grids: Array = []
var _drain_mult: float = 1.0
var _floor_containers: Array = []      # Node2D на каждый этаж
var _wall_nodes: Dictionary = {}       # Vector3i(f,gx,gy) -> StaticBody2D

var _player: CharacterBody2D
var _cp_pos: Vector2
var _cp_floor: int = 0

var _lives: int = 3
var _shards_collected: int = 0
var _shards_total: int = 0
var _keys: int = 0
var _visited: Dictionary = {}    # Vector3i(floor,cx,cy) -> true (для миникарты)
var _toast_time: float = 0.0
var _elapsed: float = 0.0
var _won: bool = false
var _dead: bool = false
var _paused: bool = false
var _game_over: bool = false

# Случайные события
var _events_enabled: bool = true
var _event_cd: float = 0.0
var _event_active: float = 0.0

# Интерфейс
var _time_label: Label
var _level_label: Label
var _win_label: Label
var _msg_label: Label
var _event_label: Label
var _end_box: CenterContainer
var _end_label: Label
var _energy_bar: ProgressBar
var _energy_fill: StyleBoxFlat
var _skill_flash: Label
var _skill_dash: Label
var _skill_sonar: Label
var _skill_shield: Label
var _skill_reveal: Label
var _lives_label: Label
var _shards_label: Label
var _keys_label: Label
var _prog_label: Label
var _toast_label: Label
var _minimap: TextureRect
var _joystick: Control
var _tint: ColorRect
var _tint_target: Color = Color(0, 0, 0, 0)
var _pause_overlay: Control
var _pause_info: Label

var _dark: CanvasModulate
var _ambient: Color
var _reveal_time: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS   # чтобы ввод работал во время паузы
	get_tree().paused = false
	get_tree().set_auto_accept_quit(true)
	# Кнопка «Назад» на Android не должна закрывать игру — обрабатываем сами
	get_tree().quit_on_go_back = false

	_level = clampi(GameConfig.level, 1, MAX_LEVEL)
	_floors = mini(_level, MAX_FLOORS)
	_cols = mini(GameConfig.cols + (_level - 1) * 6, MAX_DIM)
	_rows = mini(GameConfig.rows + (_level - 1) * 4, MAX_DIM - 12)
	_gw = _cols * 2 + 1
	_gh = _rows * 2 + 1
	_floor_gap = (_gh + 2) * TILE

	# Усложнение по уровням: быстрее разрядка и темнее фон
	_drain_mult = 1.0 + (_level - 1) * 0.07
	var dark_scale := maxf(0.45, 1.0 - (_level - 1) * 0.045)
	var a: float = GameConfig.darkness * dark_scale
	_ambient = Color(a, a, a + 0.02)

	_events_enabled = GameConfig.events_enabled
	_event_cd = randf_range(10.0, 16.0)
	_lives = maxi(1, GameConfig.lives)
	_wall_color = WALL_THEMES[(_level - 1) % WALL_THEMES.size()]

	# Автосохранение: запоминаем текущий уровень, чтобы можно было продолжить
	GameConfig.saved_level = _level
	GameConfig.save_game()

	_build_world()
	_build_hud()

func _process(delta: float) -> void:
	if _paused:
		return

	if _toast_time > 0.0:
		_toast_time -= delta
		if _toast_time <= 0.0 and _toast_label:
			_toast_label.visible = false

	if not _won and not _dead:
		_elapsed += delta
		_time_label.text = "Время: %.1f с" % _elapsed
		_update_events(delta)
		_mark_visited()

	if _player and is_instance_valid(_player):
		if _joystick:
			_player.touch_dir = _joystick.output
		var r: float = clampf(_player.energy / _player.max_energy, 0.0, 1.0)
		_energy_bar.value = r
		_energy_fill.bg_color = Color(0.9, 0.2, 0.2).lerp(Color(1.0, 0.85, 0.3), r)

		_update_skill(_skill_flash, "Q  Вспышка", _player.flash_cd, _player.energy, _player.FLASH_COST)
		_update_skill(_skill_dash, "Shift  Рывок", _player.dash_cd, _player.energy, _player.DASH_COST)
		_update_skill(_skill_sonar, "E  Сонар", _player.sonar_cd, _player.energy, _player.SONAR_COST)
		_update_skill(_skill_shield, "C  Щит", _player.shield_cd, _player.energy, _player.SHIELD_COST)
		_update_reveal(_skill_reveal, _player.reveal_charge)

		if GameConfig.progressive_enabled:
			_prog_label.text = "Разгон +%d%%   Адаптация -%d%%" % [
				int(_player.momentum_bonus * 100.0), int(_player.adapt_bonus * 100.0)]
		else:
			_prog_label.text = ""

	# Озарение
	if _dark:
		if _reveal_time > 0.0:
			_reveal_time -= delta
			_dark.color = _dark.color.lerp(Color(0.85, 0.85, 0.9), 0.12)
		else:
			_dark.color = _dark.color.lerp(_ambient, 0.06)

	# Цветовой тинт событий
	if _tint:
		_tint.color = _tint.color.lerp(_tint_target, 0.1)

# --- Случайные события ---

func _update_events(delta: float) -> void:
	if not _events_enabled or _level < 2:
		return

	if _event_active > 0.0:
		_event_active -= delta
		if _event_active <= 0.0:
			_end_event()
		return

	_event_cd -= delta
	if _event_cd <= 0.0:
		_trigger_event()

func _trigger_event() -> void:
	var roll := randf()
	var dur := randf_range(3.0, 5.0)
	var kind := ""
	if roll < 0.18:
		kind = "relief"
	elif roll < 0.40:
		kind = "fog"
	elif roll < 0.60:
		kind = "leak"
	elif roll < 0.80:
		kind = "flicker"
	else:
		kind = "shift"

	_event_active = dur

	match kind:
		"shift":
			_event_label.text = "Сдвиг стен!"
			_event_label.add_theme_color_override("font_color", Color(0.8, 0.6, 1.0))
			_tint_target = Color(0.4, 0.25, 0.6, 0.14)
			_maze_shift()
		"relief":
			_event_label.text = "Просвет!"
			_event_label.add_theme_color_override("font_color", Color(0.5, 1.0, 0.6))
			_tint_target = Color(0.2, 0.6, 0.3, 0.10)
			_reveal_time = maxf(_reveal_time, 1.6)
			if _player:
				_player.energy = minf(_player.max_energy, _player.energy + 0.3)
		"fog":
			_event_label.text = "Густой туман"
			_event_label.add_theme_color_override("font_color", Color(0.6, 0.8, 1.0))
			_tint_target = Color(0.25, 0.4, 0.7, 0.16)
			if _player:
				_player.apply_event("fog", dur)
		"leak":
			_event_label.text = "Утечка света!"
			_event_label.add_theme_color_override("font_color", Color(1.0, 0.5, 0.4))
			_tint_target = Color(0.7, 0.2, 0.2, 0.16)
			if _player:
				_player.apply_event("leak", dur)
		"flicker":
			_event_label.text = "Перебой света!"
			_event_label.add_theme_color_override("font_color", Color(1.0, 0.9, 0.4))
			_tint_target = Color(0.1, 0.1, 0.1, 0.12)
			if _player:
				_player.apply_event("flicker", dur)

	_event_label.visible = true

func _end_event() -> void:
	_event_label.visible = false
	_tint_target = Color(0, 0, 0, 0)
	# Следующее событие — реже на низких уровнях, чаще на высоких
	var lo := maxf(6.0, 16.0 - _level)
	_event_cd = randf_range(lo, lo + 8.0)

# --- Пауза ---

func _toggle_pause() -> void:
	_paused = not _paused
	get_tree().paused = _paused
	_pause_overlay.visible = _paused
	if _paused:
		_refresh_pause()

func _refresh_pause() -> void:
	var t := "[ Активные навыки ]\n"
	t += "Q — Вспышка     Shift — Рывок\n"
	t += "E — Сонар       C — Щит\n"
	if _player:
		t += "F — Озарение (%d%%)\n\n" % int(_player.reveal_charge * 100.0)
	else:
		t += "F — Озарение\n\n"

	t += "[ Пассивные навыки ]\n"
	var names := {
		"save": "Энергосбережение", "capacity": "Ёмкость",
		"charge": "Быстрая зарядка", "range": "Дальний свет",
		"legs": "Лёгкие ноги", "magic": "Эффективная магия",
	}
	var any := false
	for k in names:
		if GameConfig.passives.get(k, false):
			t += "- %s\n" % names[k]
			any = true
	if not any:
		t += "— не выбраны —\n"

	if GameConfig.progressive_enabled and _player:
		t += "\n[ Накопительные ]\n"
		t += "Разгон: +%d%% скорости\n" % int(_player.momentum_bonus * 100.0)
		t += "Адаптация: -%d%% разрядки\n" % int(_player.adapt_bonus * 100.0)

	_pause_info.text = t

	if _minimap:
		_minimap.texture = _build_minimap_texture()

func _restart() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()

func _goto_menu() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://menu.tscn")

func _notification(what: int) -> void:
	# Системная кнопка «Назад» (Android) — пауза вместо выхода
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if _won or _game_over:
			_goto_menu()
		else:
			_toggle_pause()

func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventKey and event.pressed and not event.echo):
		return
	var k: int = event.keycode

	if _won or _game_over:
		if k == KEY_R or k == KEY_SPACE:
			_restart()
		elif k == KEY_ESCAPE:
			_goto_menu()
		return

	if k == KEY_ESCAPE or k == KEY_P:
		_toggle_pause()
	elif k == KEY_R and not _paused:
		_restart()

# --- Генерация лабиринта (recursive backtracker) ---

func _make_grid() -> Array:
	var grid: Array = []
	grid.resize(_gh)
	for y in _gh:
		var row := []
		row.resize(_gw)
		for x in _gw:
			row[x] = true
		grid[y] = row

	var visited := {}
	var stack: Array[Vector2i] = []
	var start := Vector2i(0, 0)
	visited[start] = true
	grid[1][1] = false
	stack.append(start)

	while not stack.is_empty():
		var c: Vector2i = stack.back()
		var neighbors := _unvisited_neighbors(c, visited)
		if neighbors.is_empty():
			stack.pop_back()
		else:
			var n: Vector2i = neighbors[randi() % neighbors.size()]
			visited[n] = true
			grid[n.y * 2 + 1][n.x * 2 + 1] = false
			grid[c.y + n.y + 1][c.x + n.x + 1] = false
			stack.append(n)

	return grid

func _unvisited_neighbors(c: Vector2i, visited: Dictionary) -> Array[Vector2i]:
	var res: Array[Vector2i] = []
	for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
		var n: Vector2i = c + d
		if n.x >= 0 and n.x < _cols and n.y >= 0 and n.y < _rows and not visited.has(n):
			res.append(n)
	return res

# --- Построение мира ---

func _build_world() -> void:
	_dark = CanvasModulate.new()
	_dark.color = _ambient
	add_child(_dark)

	_grids.clear()
	for f in _floors:
		var grid := _make_grid()
		_grids.append(grid)
		_build_floor(f, grid)

	_place_doors()
	_place_exit()
	_spawn_player()

	# Тьма-преследователь с уровня 4
	if GameConfig.darkness_chaser and _level >= 4:
		var pc := _farthest_cell(_grids[0])
		var pur := Node2D.new()
		pur.set_script(load("res://pursuer.gd"))
		pur.position = _cell_to_world(pc)
		pur.target = _player
		add_child(pur)

func _build_floor(f: int, grid: Array) -> void:
	var container := Node2D.new()
	container.position = Vector2(0, f * _floor_gap)
	add_child(container)
	_floor_containers.resize(maxi(_floor_containers.size(), f + 1))
	_floor_containers[f] = container

	var floor_node := Polygon2D.new()
	floor_node.color = FLOOR_COLOR
	floor_node.polygon = PackedVector2Array([
		Vector2(0, 0),
		Vector2(_gw * TILE, 0),
		Vector2(_gw * TILE, _gh * TILE),
		Vector2(0, _gh * TILE),
	])
	container.add_child(floor_node)

	for gy in _gh:
		for gx in _gw:
			if grid[gy][gx]:
				_add_wall(container, f, gx, gy)

	# Станции (они же чекпоинты)
	var cells := _passage_cells(f == 0)
	cells.shuffle()
	var area: int = _cols * _rows
	var density: float = float(GameConfig.station_count) / (16 * 10)
	var lvl_factor: float = 1.0 + (mini(_level, 6) - 1) * 0.25
	var scaled: int = max(GameConfig.station_count, int(area * density * lvl_factor))
	var count: int = mini(mini(scaled, MAX_STATIONS), cells.size())
	for i in count:
		var st := Area2D.new()
		st.set_script(load("res://station.gd"))
		st.game = self
		st.floor_index = f
		st.position = _cell_to_world(cells[i])
		container.add_child(st)

	# Осколки света (собираемые бонусы)
	var shard_cells := _passage_cells(f == 0)
	shard_cells.shuffle()
	var sc: int = mini(SHARDS_PER_FLOOR, shard_cells.size())
	for i in sc:
		var sh := Area2D.new()
		sh.set_script(load("res://shard.gd"))
		sh.game = self
		sh.position = _cell_to_world(shard_cells[i])
		container.add_child(sh)
		_shards_total += 1

func _add_wall(container: Node2D, f: int, gx: int, gy: int) -> void:
	var body := StaticBody2D.new()
	body.position = Vector2(gx * TILE + TILE * 0.5, gy * TILE + TILE * 0.5)

	var col := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = Vector2(TILE, TILE)
	col.shape = rect
	body.add_child(col)

	var h := TILE * 0.5
	var square := PackedVector2Array([
		Vector2(-h, -h), Vector2(h, -h), Vector2(h, h), Vector2(-h, h),
	])

	var vis := Polygon2D.new()
	vis.color = _wall_color
	vis.polygon = square
	body.add_child(vis)

	var occ := LightOccluder2D.new()
	var occ_poly := OccluderPolygon2D.new()
	occ_poly.polygon = square
	occ_poly.closed = true
	occ.occluder = occ_poly
	body.add_child(occ)

	container.add_child(body)
	_wall_nodes[Vector3i(f, gx, gy)] = body

func _place_doors() -> void:
	var pairs: int = clampi(GameConfig.door_pairs, 1, 4)
	for f in range(_floors - 1):
		var cells := _passage_cells(true)
		cells.shuffle()
		for p in mini(pairs, cells.size()):
			var c: Vector2i = cells[p]
			var local := _cell_to_world(c)
			# Первая пара (p == 0) всегда открыта — гарантированный путь.
			# Остальные заперты и требуют осколок-ключ.
			var lock := p > 0
			var d_a := _make_door(local + Vector2(0, f * _floor_gap), _floor_gap, f + 1, lock)
			var d_b := _make_door(local + Vector2(0, (f + 1) * _floor_gap), -_floor_gap, f, lock)
			d_a.partner = d_b
			d_b.partner = d_a

func _make_door(pos: Vector2, dy: float, target_floor: int, locked: bool) -> Area2D:
	var d := Area2D.new()
	d.set_script(load("res://door.gd"))
	d.delta_y = dy
	d.target_floor = target_floor
	d.game = self
	d.locked = locked
	# Перегенерация — только если дверей не меньше 4 (иначе искать проход слишком тяжело)
	var regen_ok: bool = GameConfig.door_regen_enabled and GameConfig.door_pairs >= 4
	d.regen_chance = GameConfig.door_regen_chance if regen_ok else 0.0
	d.position = pos
	add_child(d)
	return d

func _place_exit() -> void:
	var lf := _floors - 1
	var c := _farthest_cell(_grids[lf])
	var exit := Area2D.new()
	exit.set_script(load("res://exit.gd"))
	exit.game = self
	exit.position = _cell_to_world(c) + Vector2(0, lf * _floor_gap)
	add_child(exit)

func _spawn_player() -> void:
	_player = preload("res://player.tscn").instantiate()
	_player.speed = GameConfig.player_speed
	_player.drain_per_sec = GameConfig.drain_per_sec * _drain_mult
	_player.max_energy = GameConfig.max_energy
	_player.position = _cell_to_world(Vector2i(0, 0))
	add_child(_player)

	_cp_floor = 0
	_cp_pos = _player.position

func _farthest_cell(grid: Array) -> Vector2i:
	var start := Vector2i(0, 0)
	var dist := {start: 0}
	var queue: Array[Vector2i] = [start]
	var best := start
	var best_d := 0
	while not queue.is_empty():
		var c: Vector2i = queue.pop_front()
		if dist[c] > best_d:
			best_d = dist[c]
			best = c
		for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var n: Vector2i = c + d
			if n.x < 0 or n.x >= _cols or n.y < 0 or n.y >= _rows or dist.has(n):
				continue
			var mx := c.x + n.x + 1
			var my := c.y + n.y + 1
			if not grid[my][mx]:
				dist[n] = dist[c] + 1
				queue.append(n)
	return best

func _passage_cells(exclude_start: bool) -> Array[Vector2i]:
	var arr: Array[Vector2i] = []
	for cy in _rows:
		for cx in _cols:
			if exclude_start and cx == 0 and cy == 0:
				continue
			arr.append(Vector2i(cx, cy))
	return arr

func _cell_to_world(cell: Vector2i) -> Vector2:
	var gx := cell.x * 2 + 1
	var gy := cell.y * 2 + 1
	return Vector2(gx * TILE + TILE * 0.5, gy * TILE + TILE * 0.5)

func _grid_to_world(gx: int, gy: int, f: int) -> Vector2:
	return Vector2(gx * TILE + TILE * 0.5, gy * TILE + TILE * 0.5) + Vector2(0, f * _floor_gap)

func _mark_visited() -> void:
	if _player == null or not is_instance_valid(_player):
		return
	var f: int = _player.current_floor
	var px: float = _player.global_position.x
	var py: float = _player.global_position.y - f * _floor_gap
	var cx: int = int(round((px / TILE - 1.5) / 2.0))
	var cy: int = int(round((py / TILE - 1.5) / 2.0))
	if cx >= 0 and cx < _cols and cy >= 0 and cy < _rows:
		_visited[Vector3i(f, cx, cy)] = true

func _build_minimap_texture() -> ImageTexture:
	var img := Image.create_empty(_cols, _rows, false, Image.FORMAT_RGBA8)
	img.fill(Color(0.08, 0.08, 0.11, 1.0))
	var f: int = _player.current_floor if (_player and is_instance_valid(_player)) else 0
	var cur := Vector2i(-1, -1)
	if _player and is_instance_valid(_player):
		var px: float = _player.global_position.x
		var py: float = _player.global_position.y - f * _floor_gap
		cur = Vector2i(int(round((px / TILE - 1.5) / 2.0)), int(round((py / TILE - 1.5) / 2.0)))
	for key in _visited:
		if key.x == f and key.y >= 0 and key.y < _cols and key.z >= 0 and key.z < _rows:
			img.set_pixel(key.y, key.z, Color(0.5, 0.85, 0.7))
	if cur.x >= 0 and cur.x < _cols and cur.y >= 0 and cur.y < _rows:
		img.set_pixel(cur.x, cur.y, Color(1.0, 0.9, 0.4))
	return ImageTexture.create_from_image(img)

# --- Изменение структуры лабиринта ---

func _set_wall(f: int, gx: int, gy: int, is_wall: bool) -> void:
	(_grids[f] as Array)[gy][gx] = is_wall
	var key := Vector3i(f, gx, gy)
	if is_wall:
		if not _wall_nodes.has(key):
			_add_wall(_floor_containers[f], f, gx, gy)
	else:
		if _wall_nodes.has(key):
			_wall_nodes[key].queue_free()
			_wall_nodes.erase(key)

# Путь между двумя клетками-проходами по текущему дереву (в координатах сетки),
# возвращает список рёбер-стен на пути. Ребро exclude игнорируется.
func _path_edges(grid: Array, a: Vector2i, b: Vector2i, exclude: Vector2i) -> Array:
	var prev := {}
	var visited := {a: true}
	var queue: Array[Vector2i] = [a]
	while not queue.is_empty():
		var c: Vector2i = queue.pop_front()
		if c == b:
			break
		for d in [Vector2i(2, 0), Vector2i(-2, 0), Vector2i(0, 2), Vector2i(0, -2)]:
			var n: Vector2i = c + d
			if n.x < 1 or n.x >= _gw - 1 or n.y < 1 or n.y >= _gh - 1:
				continue
			var edge := Vector2i((c.x + n.x) / 2, (c.y + n.y) / 2)
			if edge == exclude or grid[edge.y][edge.x] or visited.has(n):
				continue
			visited[n] = true
			prev[n] = [c, edge]
			queue.append(n)
	if not visited.has(b):
		return []
	var edges: Array = []
	var cur: Vector2i = b
	while cur != a:
		var pe = prev[cur]
		edges.append(pe[1])
		cur = pe[0]
	return edges

# Случайное событие: открыть одно ребро и закрыть другое на образовавшемся
# цикле — лабиринт меняется, но остаётся проходимым (остаётся деревом).
func _maze_shift() -> void:
	if _player == null:
		return
	var f: int = _player.current_floor
	if f < 0 or f >= _grids.size():
		return
	var grid: Array = _grids[f]

	var closed: Array = []
	for gy in range(1, _gh - 1):
		for gx in range(1, _gw - 1):
			if not grid[gy][gx]:
				continue
			# ребро между двумя проходами: ровно одна координата чётная
			if (gx % 2 == 0) == (gy % 2 == 0):
				continue
			closed.append(Vector2i(gx, gy))
	if closed.is_empty():
		return
	closed.shuffle()
	var opened: Vector2i = closed[0]

	var a: Vector2i
	var b: Vector2i
	if opened.x % 2 == 0:
		a = Vector2i(opened.x - 1, opened.y)
		b = Vector2i(opened.x + 1, opened.y)
	else:
		a = Vector2i(opened.x, opened.y - 1)
		b = Vector2i(opened.x, opened.y + 1)

	var path := _path_edges(grid, a, b, opened)
	if path.is_empty():
		return

	_set_wall(f, opened.x, opened.y, false)  # открыли проход

	# закрыть ребро на пути, не вплотную к игроку
	path.shuffle()
	var to_close: Vector2i = path[0]
	for e in path:
		if _grid_to_world(e.x, e.y, f).distance_to(_player.global_position) > TILE * 2.0:
			to_close = e
			break
	_set_wall(f, to_close.x, to_close.y, true)

# Полная перегенерация этажа (для события у дверей).
# Постройка разбита на кадры, чтобы не было фриза на больших лабиринтах.
func regenerate_floor(f: int) -> void:
	if f < 0 or f >= _grids.size() or f >= _floor_containers.size():
		return
	for key in _wall_nodes.keys():
		if key.x == f:
			_wall_nodes[key].queue_free()
			_wall_nodes.erase(key)
	var grid := _make_grid()
	_grids[f] = grid
	# Сбрасываем пройденный путь этого этажа — карта обнуляется
	for vk in _visited.keys():
		if vk.x == f:
			_visited.erase(vk)
	var container: Node2D = _floor_containers[f]
	var built := 0
	for gy in _gh:
		for gx in _gw:
			if grid[gy][gx]:
				_add_wall(container, f, gx, gy)
				built += 1
				if built % 100 == 0:
					await get_tree().process_frame
					if not is_instance_valid(container):
						return

# --- Игровые события ---

func set_checkpoint(floor_idx: int, pos: Vector2) -> void:
	_cp_floor = floor_idx
	_cp_pos = pos

func reveal(duration: float) -> void:
	_reveal_time = duration

func on_player_death() -> void:
	if _dead or _won or _game_over:
		return
	_lives -= 1
	_update_lives()

	if _lives <= 0:
		_game_over = true
		_end_label.text = "ИГРА ОКОНЧЕНА"
		_end_label.add_theme_color_override("font_color", Color(1.0, 0.5, 0.5))
		_end_box.visible = true
		return

	_dead = true
	_msg_label.text = "Свет погас!  Осталось жизней: %d\nВозврат к последней станции…" % _lives
	_msg_label.visible = true
	await get_tree().create_timer(1.2).timeout
	if not is_instance_valid(_player):
		return
	_player.respawn(_cp_pos, _cp_floor)
	_msg_label.visible = false
	_dead = false

func _update_lives() -> void:
	if _lives_label:
		_lives_label.text = "Жизни: %d" % maxi(_lives, 0)

func collect_shard() -> void:
	_shards_collected += 1
	_keys += 1
	_update_shards()

func use_key() -> bool:
	if _keys > 0:
		_keys -= 1
		_update_shards()
		return true
	return false

func _update_shards() -> void:
	if _shards_label:
		_shards_label.text = "Осколки: %d / %d" % [_shards_collected, _shards_total]
	if _keys_label:
		_keys_label.text = "Ключи: %d" % _keys

func flash_message(text: String) -> void:
	if _toast_label:
		_toast_label.text = text
		_toast_label.visible = true
		_toast_time = 1.6

func on_player_win() -> void:
	if _won:
		return
	_won = true
	if _player:
		_player.active = false

	if _level < MAX_LEVEL:
		_win_label.text = "Уровень %d пройден!\nВремя: %.1f с" % [_level, _elapsed]
		_win_label.visible = true
		await get_tree().create_timer(1.6).timeout
		GameConfig.level = _level + 1
		_restart()
	else:
		_end_label.text = "ПОБЕДА!\nВсе %d уровней пройдены\nВремя: %.1f с" % [MAX_LEVEL, _elapsed]
		_end_box.visible = true

# --- Интерфейс ---

func _make_skill_label(layer: CanvasLayer, y: int) -> Label:
	var lbl := Label.new()
	lbl.position = Vector2(28, y)
	lbl.add_theme_font_size_override("font_size", 17)
	layer.add_child(lbl)
	return lbl

func _build_hud() -> void:
	# Слой тинта (под HUD, над миром)
	var fx := CanvasLayer.new()
	fx.layer = 1
	add_child(fx)

	_tint = ColorRect.new()
	_tint.set_anchors_preset(Control.PRESET_FULL_RECT)
	_tint.color = Color(0, 0, 0, 0)
	_tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fx.add_child(_tint)

	var layer := CanvasLayer.new()
	layer.layer = 2
	add_child(layer)

	_level_label = Label.new()
	_level_label.text = "Уровень %d  (этажей: %d)" % [_level, _floors]
	_level_label.position = Vector2(16, 10)
	_level_label.add_theme_font_size_override("font_size", 20)
	layer.add_child(_level_label)

	_time_label = Label.new()
	_time_label.position = Vector2(16, 38)
	_time_label.add_theme_font_size_override("font_size", 20)
	layer.add_child(_time_label)

	var right_x: float = get_viewport().get_visible_rect().size.x - 190

	_lives_label = Label.new()
	_lives_label.position = Vector2(right_x, 12)
	_lives_label.add_theme_font_size_override("font_size", 22)
	_lives_label.add_theme_color_override("font_color", Color(1.0, 0.5, 0.5))
	layer.add_child(_lives_label)
	_update_lives()

	_shards_label = Label.new()
	_shards_label.position = Vector2(right_x, 42)
	_shards_label.add_theme_font_size_override("font_size", 20)
	_shards_label.add_theme_color_override("font_color", Color(1.0, 0.92, 0.5))
	layer.add_child(_shards_label)

	_keys_label = Label.new()
	_keys_label.position = Vector2(right_x, 68)
	_keys_label.add_theme_font_size_override("font_size", 20)
	_keys_label.add_theme_color_override("font_color", Color(0.9, 0.75, 0.4))
	layer.add_child(_keys_label)
	_update_shards()

	var bar_label := Label.new()
	bar_label.text = "Свет"
	bar_label.position = Vector2(16, 70)
	bar_label.add_theme_font_size_override("font_size", 16)
	layer.add_child(bar_label)

	_energy_bar = ProgressBar.new()
	_energy_bar.min_value = 0.0
	_energy_bar.max_value = 1.0
	_energy_bar.step = 0.001
	_energy_bar.show_percentage = false
	_energy_bar.value = 1.0
	_energy_bar.position = Vector2(70, 70)
	_energy_bar.custom_minimum_size = Vector2(280, 22)

	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.12, 0.12, 0.16)
	bg.set_corner_radius_all(4)
	_energy_bar.add_theme_stylebox_override("background", bg)

	_energy_fill = StyleBoxFlat.new()
	_energy_fill.bg_color = Color(1.0, 0.85, 0.3)
	_energy_fill.set_corner_radius_all(4)
	_energy_bar.add_theme_stylebox_override("fill", _energy_fill)
	layer.add_child(_energy_bar)

	var skills_title := Label.new()
	skills_title.text = "Навыки:"
	skills_title.position = Vector2(16, 104)
	skills_title.add_theme_font_size_override("font_size", 16)
	skills_title.add_theme_color_override("font_color", Color(0.7, 0.7, 0.75))
	layer.add_child(skills_title)

	_skill_flash = _make_skill_label(layer, 128)
	_skill_dash = _make_skill_label(layer, 152)
	_skill_sonar = _make_skill_label(layer, 176)
	_skill_shield = _make_skill_label(layer, 200)
	_skill_reveal = _make_skill_label(layer, 224)

	_prog_label = Label.new()
	_prog_label.position = Vector2(16, 256)
	_prog_label.add_theme_font_size_override("font_size", 15)
	_prog_label.add_theme_color_override("font_color", Color(0.6, 0.85, 0.7))
	layer.add_child(_prog_label)

	var hint := Label.new()
	hint.text = "P / Esc — пауза"
	hint.position = Vector2(16, 286)
	hint.add_theme_font_size_override("font_size", 14)
	hint.add_theme_color_override("font_color", Color(0.5, 0.5, 0.55))
	layer.add_child(hint)

	# Короткое сообщение (тост) — снизу по центру
	_toast_label = Label.new()
	_toast_label.visible = false
	_toast_label.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	_toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast_label.position = Vector2(0, -80)
	_toast_label.add_theme_font_size_override("font_size", 24)
	_toast_label.add_theme_color_override("font_color", Color(1.0, 0.7, 0.4))
	layer.add_child(_toast_label)

	# Сообщение о событии (вверху по центру)
	_event_label = Label.new()
	_event_label.visible = false
	_event_label.set_anchors_preset(Control.PRESET_TOP_WIDE)
	_event_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_event_label.position = Vector2(0, 24)
	_event_label.add_theme_font_size_override("font_size", 28)
	layer.add_child(_event_label)

	# Сообщение о смерти
	_msg_label = Label.new()
	_msg_label.visible = false
	_msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_msg_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_msg_label.add_theme_font_size_override("font_size", 36)
	_msg_label.add_theme_color_override("font_color", Color(1.0, 0.4, 0.4))
	_msg_label.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(_msg_label)

	# Экран победы
	_win_label = Label.new()
	_win_label.visible = false
	_win_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_win_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_win_label.add_theme_font_size_override("font_size", 44)
	_win_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.3))
	_win_label.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(_win_label)

	# Экран конца игры (финальная победа / game over) — с кнопками для мобильных
	_end_box = CenterContainer.new()
	_end_box.set_anchors_preset(Control.PRESET_FULL_RECT)
	_end_box.visible = false
	layer.add_child(_end_box)

	var ev := VBoxContainer.new()
	ev.alignment = BoxContainer.ALIGNMENT_CENTER
	ev.add_theme_constant_override("separation", 22)
	_end_box.add_child(ev)

	_end_label = Label.new()
	_end_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_end_label.add_theme_font_size_override("font_size", 44)
	_end_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.3))
	ev.add_child(_end_label)

	var eb := HBoxContainer.new()
	eb.alignment = BoxContainer.ALIGNMENT_CENTER
	eb.add_theme_constant_override("separation", 16)
	ev.add_child(eb)
	eb.add_child(_make_overlay_button("Заново", _restart))
	eb.add_child(_make_overlay_button("В меню", _goto_menu))

	_build_pause_overlay(layer)

	if DisplayServer.is_touchscreen_available() or GameConfig.touch_controls:
		_build_touch_controls(layer)

func _build_touch_controls(layer: CanvasLayer) -> void:
	# Виртуальный джойстик (слева) — занимает весь экран, реагирует на левую половину
	_joystick = Control.new()
	_joystick.set_script(load("res://touch_joystick.gd"))
	_joystick.process_mode = Node.PROCESS_MODE_PAUSABLE
	layer.add_child(_joystick)

	var vw: float = get_viewport().get_visible_rect().size.x
	var vh: float = get_viewport().get_visible_rect().size.y

	# Кнопки навыков (справа снизу)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	grid.position = Vector2(vw - 230, vh - 250)
	grid.process_mode = Node.PROCESS_MODE_PAUSABLE
	layer.add_child(grid)

	grid.add_child(_make_touch_button("Вспышка", func(): _skill(0)))
	grid.add_child(_make_touch_button("Рывок", func(): _skill(1)))
	grid.add_child(_make_touch_button("Сонар", func(): _skill(2)))
	grid.add_child(_make_touch_button("Щит", func(): _skill(3)))
	grid.add_child(_make_touch_button("Озарение", func(): _skill(4)))

	# Кнопка паузы (справа сверху)
	var pause_btn := _make_touch_button("II", _toggle_pause)
	pause_btn.custom_minimum_size = Vector2(70, 44)
	pause_btn.position = Vector2(vw * 0.5 - 35, 6)
	pause_btn.process_mode = Node.PROCESS_MODE_PAUSABLE
	layer.add_child(pause_btn)

func _make_touch_button(text: String, on_pressed: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(108, 60)
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", 18)
	b.modulate = Color(1, 1, 1, 0.85)
	b.pressed.connect(on_pressed)
	return b

func _skill(which: int) -> void:
	if not (_player and is_instance_valid(_player)):
		return
	match which:
		0: _player._try_flash()
		1: _player._try_dash()
		2: _player._try_sonar()
		3: _player._try_shield()
		4: _player._try_reveal()

func _build_pause_overlay(layer: CanvasLayer) -> void:
	_pause_overlay = Control.new()
	_pause_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	_pause_overlay.visible = false
	_pause_overlay.process_mode = Node.PROCESS_MODE_ALWAYS
	layer.add_child(_pause_overlay)

	var bg := ColorRect.new()
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.03, 0.03, 0.06, 0.9)
	_pause_overlay.add_child(bg)

	# Корневой контейнер на весь экран с отступами: заголовок сверху,
	# прокрутка по центру, кнопки закреплены снизу (не уезжают за экран).
	var root := VBoxContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.offset_left = 40
	root.offset_top = 20
	root.offset_right = -40
	root.offset_bottom = -20
	root.add_theme_constant_override("separation", 10)
	_pause_overlay.add_child(root)

	var title := Label.new()
	title.text = "ПАУЗА"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 40)
	title.add_theme_color_override("font_color", Color(1.0, 0.85, 0.3))
	root.add_child(title)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(scroll)

	var inner := VBoxContainer.new()
	inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inner.add_theme_constant_override("separation", 8)
	scroll.add_child(inner)

	_pause_info = Label.new()
	_pause_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_pause_info.add_theme_font_size_override("font_size", 17)
	inner.add_child(_pause_info)

	var map_title := Label.new()
	map_title.text = "Карта (пройденный путь)"
	map_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	map_title.add_theme_font_size_override("font_size", 16)
	map_title.add_theme_color_override("font_color", Color(0.7, 0.7, 0.8))
	inner.add_child(map_title)

	_minimap = TextureRect.new()
	_minimap.custom_minimum_size = Vector2(300, 170)
	_minimap.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_minimap.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_minimap.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_minimap.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	inner.add_child(_minimap)

	var buttons := HBoxContainer.new()
	buttons.alignment = BoxContainer.ALIGNMENT_CENTER
	buttons.add_theme_constant_override("separation", 12)
	root.add_child(buttons)
	buttons.add_child(_make_overlay_button("Продолжить", _toggle_pause))
	buttons.add_child(_make_overlay_button("Заново", _restart))
	buttons.add_child(_make_overlay_button("В меню", _goto_menu))

func _make_overlay_button(text: String, on_pressed: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(200, 46)
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", 20)
	b.pressed.connect(on_pressed)
	return b

func _update_reveal(lbl: Label, charge: float) -> void:
	if charge >= 1.0:
		lbl.text = "F  Озарение  [готово]"
		lbl.modulate = Color(1.0, 0.85, 0.3)
	else:
		lbl.text = "F  Озарение  %d%%" % int(charge * 100.0)
		lbl.modulate = Color(0.45, 0.45, 0.5)

func _update_skill(lbl: Label, name_text: String, cd: float, energy: float, cost: float) -> void:
	if cd > 0.05:
		lbl.text = "%s  (%.1f)" % [name_text, cd]
		lbl.modulate = Color(0.45, 0.45, 0.5)
	elif energy < cost:
		lbl.text = name_text
		lbl.modulate = Color(0.6, 0.4, 0.4)
	else:
		lbl.text = name_text
		lbl.modulate = Color(0.75, 0.9, 1.0)
