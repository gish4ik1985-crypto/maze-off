class_name MazeTextures
extends RefCounted

# Общие генераторы текстур, чтобы не дублировать код в игроке и станциях.

static func make_ball(radius: int, color: Color = Color.WHITE) -> ImageTexture:
	var d := radius * 2
	var img := Image.create_empty(d, d, false, Image.FORMAT_RGBA8)
	for y in d:
		for x in d:
			var dist := Vector2(x - radius, y - radius).length()
			if dist <= radius:
				var a: float = clampf(1.0 - (dist - (radius - 2.0)) / 2.0, 0.0, 1.0)
				img.set_pixel(x, y, Color(color.r, color.g, color.b, a))
			else:
				img.set_pixel(x, y, Color(color.r, color.g, color.b, 0.0))
	return ImageTexture.create_from_image(img)

static func make_light(size: int) -> GradientTexture2D:
	var grad := Gradient.new()
	grad.set_color(0, Color(1, 1, 1, 1))
	grad.set_color(1, Color(1, 1, 1, 0))
	var tex := GradientTexture2D.new()
	tex.gradient = grad
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.5)
	tex.width = size
	tex.height = size
	return tex

static func make_ring(size: int) -> GradientTexture2D:
	# Светящееся кольцо: яркая полоса ближе к краю (для сонара).
	var grad := Gradient.new()
	grad.offsets = PackedFloat32Array([0.0, 0.62, 0.82, 1.0])
	grad.colors = PackedColorArray([
		Color(1, 1, 1, 0),
		Color(1, 1, 1, 0),
		Color(1, 1, 1, 1),
		Color(1, 1, 1, 0),
	])
	var tex := GradientTexture2D.new()
	tex.gradient = grad
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.5)
	tex.fill_to = Vector2(1.0, 0.5)
	tex.width = size
	tex.height = size
	return tex
